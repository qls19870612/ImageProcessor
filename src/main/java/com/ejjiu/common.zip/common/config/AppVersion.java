package com.ejjiu.common.config;

public class AppVersion {

    public final static String version="1.0.0";


}